#!/system/xbin/bash
clear
blue='\e[1;34m'
green='\e[1;32m'                                        
purple='\[1;35m'
cyan='\e[1;36m'
red='\e[1;31m'
white='\e[1;37m'                                           
yellow='\e[1;33m'
sleep 1
echo '\033[36;1m'
echo "#############################################"
echo "#                                           #"                                                                #"
echo "#    ###       ###  ######## ########       #"                      #"                    
echo "#    ###       ###  ######## ##             #"                                #"       
echo "#    ###       ###    ###    ######         #"                         #"
echo "#    ###       ###    ###    ######         #"                          #"
echo "#    ########  ###    ###    ##             #"                             #" 
echo "#    ########  ###    ###    ########       #"                          #"
echo "#                                           #"                                                               #"
echo "#############################################"
echo "#/     program  :LITETOOLS                 \#"
echo "#      team     :Indonesia Security Lite    #"
echo "#      create by:T2.K3Y                     #"
echo "#\     C. FB    :Rizki Key                 /#"
echo "#############################################"

echo ""
sleep 1
echo "                happy fun XD"
echo '\033[32;1m'
echo "#############################################"
sleep 1
echo "1. LITESPAM"
echo "2. LITEDDOS"
echo "3. Carding"
echo "4. Whois LookUp"
echo "5. pembuat sc deface"
echo "6. ReConDog Tools"
echo "7. Admin Login Finder"
echo "8. auto comment fb"
echo "9. multi brute force fb"
echo "10. Vbug (virus)"
echo "11. Fun XD"
echo "0. keluar"
echo "#############################################"
echo "silahkan pilih nomor brapa:"
read tod

if [ $tod = 1 ] || [ $tod = 1 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
pkg install git
pkg install toilet
pkg install figlet
cd LITESPAM
sh LITESPAM.sh
fi

if
[ $tod = 2 ] || [ $tod = 2 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
cd LITEDDOS
python2 LITEDDOS.py
fi

if [ $tod = 3 ] || [ $tod = 3 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
pkg install php
php key.php
fi

if [ $tod = 4 ] || [ $tod = 4 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
python2 whs.py
fi

if [ $tod = 5 ] || [ $tod = 5 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
python2 create.py
fi

if [ $tod = 6 ] || [ $tod = 6 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
python2 dog.py
fi

if [ $tod = 7 ] || [ $tod = 7 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
python2 gam.py
fi

if [ $tod = 8 ] || [ $tod = 8 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
python2 bot_komen.py
fi

if [ $tod = 9 ] || [ $tod = 9 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
python2 MBF.py
fi

if [ $tod = 10 ] || [ $tod = 10 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
python2 vbugmap.py
fi

if [ $tod = 11 ] || [ $tod = 11 ]
then
clear
echo '\033[36;1m'
figlet "LITETOOLS"
termux-setup-storage
pkg install sl
sl
fi

if [ $tod = 0 ] || [ $tod = 0 ]
then
sleep 1
figlet "We Are Family Indonesia Security Lite"
sleep 1
exit
fi

    
    
