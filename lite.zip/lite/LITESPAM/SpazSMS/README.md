# SpazSMS
SpazSMS uses the registration message API to send unsolicited messages (spam), as well as sending messages repeatedly on the same phone number.
