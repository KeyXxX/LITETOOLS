#!/system/xbin/bash
clear
toilet -f slant --gay "LiteSpam"
sleep 1
echo "\033[31;1m Macam-macam tool untuk spam"
sleep 1
echo "\033[33;1m Author: Mr.Rm"
sleep 1
echo "\033[32;1m ★contack: +15877711462"
sleep 1
echo "\033[34;1m ★Indonesia Security Lite"
sleep 1
echo "\033[36;1m Spam Yang Tersedia :"
echo "1. Tokopedia"
echo "2. Telkomsel"
echo "3. Matahari Mall"
echo "4. PHD"
echo "5. Jd.Id"
echo "6. Email Bomber"
echo "0. Keluar"
echo "\033[30;1m81. Informasi Tool Ini"
echo "\033[33;1m Pilih Angka:"
read mrrm
if [ $mrrm = 1 ] || [ $mrrm = 1 ]
then
clear
echo "\033[34;1m"
figlet "tokopedia"
php 1.php
fi

if
[ $mrrm = 2 ] || [ $mrrm = 2 ]
then
clear
echo "\033[31;1m"
toilet "T-Sel"
php 2.php
fi

if [ $mrrm = 3 ] || [ $mrrm = 3 ]
then
clear
echo "\033[31;1m"
figlet "Mthr Mall"
php 3.php
fi


if [ $mrrm = 4 ] || [ $mrrm = 4 ]
then
clear
toilet -f mono12 -F gay "PHD"
echo "\033[30;1m"
php 4.php
fi

if
[ $mrrm = 5 ] || [ $mrrm = 5 ]
then
clear
toilet -f mono12 -F gay "Jd.Id"
echo "\033[33;1m"
php 5.php
fi

if
[ $mrrm = 6 ] || [ $mrrm = 6 ]
then
clear
toilet -f standard -F gay "Email Bomber"
echo "\033[36;1m"
python2 6.py
fi

if
[ $mrrm = 81 ] || [ $mrrm = 81 ]
then
clear
toilet -f slant --gay "LiteSpam"
echo "\033[31;1mNama tools: LiteSpam"
sleep 1
echo "\033[33;1mKarya: Mr.Rm (V2 By Mr.IM81)"
sleep 1
echo "\033[32;1mVersi: v2"
sleep 1
echo "\033[36;1mTeam: ★Indonesia Security Lite★"
sleep 1
echo "\033[34;1mInformasi Lebih Lanjut Kunjungi: https://www.github.com/4L13199"
echo "\033[31;1m Spesial Thanks To: "
echo "\033[36;1m"
echo "Handika Pratama"
echo "まやちゃん"
echo "Baby Cyber Team"
echo "SBG-Team"
echo "Ponorogo Defacer Team"
sleep 1
echo "And All Member Indonesia Security Lite"
echo "\033[30;1m tunggu 8 detik"
sleep 8
sh LITESPAM.sh
fi

if
[ $mrrm = 0 ] || [ $mrrm = 0 ]
then
echo "\033[31;1m Keluar"
sleep 1
echo "\033[32;1m Sampai berjumpa lagi :)"
sleep 1
fi

